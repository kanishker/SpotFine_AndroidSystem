package com.example.kanishker.spotfinewlv;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnenter = (Button) findViewById(R.id.btn_enter);

        Button dlog = (Button) findViewById(R.id.btn_dialog);

        btnenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intt = new Intent(getApplicationContext(),ViewUser.class);
                startActivity(intt);

            }
        });

        dlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mbuilder = new AlertDialog.Builder(MainActivity.this);
                View mview = getLayoutInflater().inflate(R.layout.dialog_login,null);

                final EditText memail = (EditText) mview.findViewById(R.id.txt_email);
                final EditText mpassword= (EditText) mview.findViewById(R.id.txt_pword);
                Button mloginn= (Button) mview.findViewById(R.id.btn_login);


                mloginn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(!memail.getText().toString().isEmpty()&& !mpassword.getText().toString().isEmpty())
                        {
                            Toast.makeText(MainActivity.this,
                                   // R.string.success_login_msg,
                                    "login Successful", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this,
                                    "Please Fill in the rest of the details to login", Toast.LENGTH_SHORT).show();

                        }

                    }
                });
                mbuilder.setView(mview);
                AlertDialog Dialog = mbuilder.create();
                Dialog.show();




            }
        });
    }
}
